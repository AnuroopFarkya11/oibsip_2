package com.example.tasko;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
//                            MAIN HOME SCREEN CODE
public class Main extends AppCompatActivity {


    ConstraintLayout constraintLayout;
    TextView showDate;

    //Welcome greet
    TextView name;

    //For no task indication
    ImageView notask;
    TextView notasktext;

    //ADD TASK BUTTON
    ImageButton add;

    //Edittext for input from dialog
    EditText task;
    ImageButton save;

    //Setting up recycler view
    RecyclerView showTask;

    List<String> alltasks = new ArrayList<String>();


    //MONTHS list
    List<String> months = new ArrayList<>();
    int task_enter = 0;//task enter nhi hua hai

//    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        View view =

        //Recycle view
//        ProgrammingAdapter programmingAdapter = new ProgrammingAdapter(alltasks);

        //Dates layout
        constraintLayout = findViewById(R.id.showingDate);
        showDate = findViewById(R.id.fullDate);

//        delete = findViewById(R.id.trash);
        //No task
        notask = findViewById(R.id.notask);
        notasktext = findViewById(R.id.notask1);

        //Add task Button
        add = findViewById(R.id.addbtn);

        //Welcome greet Hi user
        name = findViewById(R.id.name);
        SharedPreferences sharedPreferences = getSharedPreferences("User", Context.MODE_PRIVATE);
        String user = sharedPreferences.getString("user",null);
        name.setText(user);

//        alltasks = findViewById(R.id.recyclerView);

        //MONTHS LIST
        months.add(0,"Select Month");
        months.add(1,"January");
        months.add(2,"February");
        months.add(3,"March");
        months.add(4,"April");
        months.add(5,"May");
        months.add(6,"June");
        months.add(7,"July");
        months.add(8,"August");
        months.add(9,"September");
        months.add(10,"October");
        months.add(11,"November");
        months.add(12,"December");
        months.add(13,"NUll");

        //Setting up current date
        Calendar calendar = Calendar.getInstance();
        String date = String.valueOf(calendar.get(Calendar.DAY_OF_MONTH));
        String month = months.get((calendar.get(Calendar.MONTH))+1);
        String year =String.valueOf(calendar.get(Calendar.YEAR));
        final String[] currentDate = {date + ", " + month + " " + year};
//        int currentIntDate = calendar.get(Calendar.DAY_OF_MONTH) + calendar.

        showDate.setText(currentDate[0]);

        showTask = findViewById(R.id.recyclerView);

        MyTaskHandler myTaskHandler = new MyTaskHandler(this,showTask);

        alltasks =myTaskHandler.showTask(user,currentDate[0]);
        if(!alltasks.isEmpty()) {
            showTask.setLayoutManager(new LinearLayoutManager(Main.this));
            showTask.setAdapter(new ProgrammingAdapter(alltasks,Main.this,user,currentDate[0],showTask));
            notask.setVisibility(View.GONE);
            notasktext.setVisibility(View.GONE);

        }else{
            notask.setVisibility(View.VISIBLE);
            notasktext.setVisibility(View.VISIBLE);

        }

            //Click listener to Date! + DatePickerDialogue

            constraintLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

//                Toast.makeText(Home2.this, "Dialogue", Toast.LENGTH_SHORT).show();
                    final Calendar calendar = Calendar.getInstance();
                    int mYear, mMonth, mDay;


                    mYear = calendar.get(Calendar.YEAR);
                    mMonth = calendar.get(Calendar.MONTH);
                    mDay = calendar.get(Calendar.DAY_OF_MONTH);

                    DatePickerDialog datePickerDialog = new DatePickerDialog(Main.this, new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {

                            String dat = String.valueOf(i2);
                            String mahina = months.get(i1 + 1);
                            String year = String.valueOf(i);
                            currentDate[0] = dat + ", " + mahina + " " + year;
                            showDate.setText(currentDate[0]);

                            List<String> presentTask = new ArrayList<>();
                            presentTask =myTaskHandler.showTask(user,currentDate[0]);
                            if(!presentTask.isEmpty()) {
                                showTask.setLayoutManager(new LinearLayoutManager(Main.this));
                                showTask.setAdapter(new ProgrammingAdapter(presentTask,Main.this,user,currentDate[0],showTask));
                                notask.setVisibility(View.GONE);
                                notasktext.setVisibility(View.GONE);

                            }
                            else{
                                showTask.setLayoutManager(new LinearLayoutManager(Main.this));
                                showTask.setAdapter(new ProgrammingAdapter(presentTask,Main.this,user,currentDate[0],showTask));
                                notask.setVisibility(View.VISIBLE);
                                notasktext.setVisibility(View.VISIBLE);
                            }
                        }
                    }, mYear, mMonth, mDay);
                    datePickerDialog.show();

                }
            });


            //Setting up no task
//        int task_cnt= programmingAdapter.getItemCount();
//            if (task_enter == 0) {
//                notask.setVisibility(View.VISIBLE);
//                notasktext.setVisibility(View.VISIBLE);
//            } else {
//                notask.setVisibility(View.GONE);
//                notasktext.setVisibility(View.GONE);
//
//            }

            Dialog dialog = new Dialog(Main.this);
            dialog.setContentView(R.layout.take_input);
            //ADD TASK BUTTON
            add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //A dialog will get open!
//                Dialog dialog = new Dialog(Main.this);
//                dialog.setContentView(R.layout.take_input);

                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    dialog.show();

                }
            });

            //Taking input from dialog and will pass to task handler ,also will call recycler view
            save = dialog.findViewById(R.id.addTask);
            task = dialog.findViewById(R.id.inputTask);

//        MyTaskHandler myTaskHandler = new MyTaskHandler(this);


            save.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {
                    String itask = task.getText().toString();
                    Toast.makeText(Main.this, "Task Added!", Toast.LENGTH_SHORT).show();
                    myTaskHandler.addTask(currentDate[0], user, "Ramji", itask);

                    alltasks = myTaskHandler.showTask(user, currentDate[0]);
                    showTask.setLayoutManager(new LinearLayoutManager(Main.this));
                    showTask.setAdapter(new ProgrammingAdapter(alltasks,Main.this,user,currentDate[0],showTask));
                    notask.setVisibility(View.GONE);
                    notasktext.setVisibility(View.GONE);
                    dialog.dismiss();
                    task.setText("");


                }
            });





    }


}