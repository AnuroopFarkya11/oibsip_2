package com.example.tasko;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;


//                                               SPLASH SCREEN
public class splash extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splashscreen);

        getSupportActionBar().hide();


        SharedPreferences shared = getSharedPreferences("Logged", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = shared.edit();
        String check = shared.getString("Login","null");

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {



                Log.d("Checking",check);
                if(check.equals("True"))
                {
                    Intent intent = new Intent(splash.this,Continue.class);
                    startActivity(intent);
                    finish();
                }
                else
                {
                    Intent intent = new Intent(splash.this, home.class);
                    startActivity(intent);
                    finish();
                }

            }
        },3000);
    }
}