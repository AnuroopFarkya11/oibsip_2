package com.example.tasko;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ProgrammingAdapter extends RecyclerView.Adapter<ProgrammingAdapter.ProgrammingViewHolder> {
    private List<String> list = new ArrayList<>();
    Context context;
    String cdate,cuser;
    RecyclerView showTask;
    //Default Constructor
    public ProgrammingAdapter()
    {

    }

    //Parameterized Method Takes a list as parameter

    public ProgrammingAdapter(List<String> list, Context context, String user, String date, RecyclerView showTask)
    {
        this.list=list;
        this.context=context;
        cdate = date;
        cuser = user;
        this.showTask =showTask;
    }


    //what should be the view when no input is there!

    @Override
    public ProgrammingViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.list_item,parent,false);

        return new ProgrammingViewHolder(view);
    }


    @Override
    public void onBindViewHolder( ProgrammingViewHolder holder, int position) {

        String title = list.get(position);
        holder.txt.setText(title);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ProgrammingViewHolder extends RecyclerView.ViewHolder{
        ImageView arrow;
        ImageButton trash;
        TextView txt;

        public ProgrammingViewHolder(View itemView) {
            super(itemView);
            arrow = (ImageView) itemView.findViewById(R.id.arrow);
            trash = itemView.findViewById(R.id.trash);
            txt = (TextView) itemView.findViewById(R.id.input);
            MyTaskHandler myTaskHandler = new MyTaskHandler(context,showTask);
            trash.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String task = txt.getText().toString();
                    Toast.makeText(context, "Deleting"+cdate+cuser, Toast.LENGTH_SHORT).show();
                    myTaskHandler.delete(cuser,cdate,task);
//                    context.simple(1);
                }
            });
        }
    }
}
