package com.example.tasko;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
//                                               CONTINUE SCREEN : CONTINUE THE APP TO MAIN SCREEN IF USER CHECKED THE REMEMBER ME

public class Continue extends AppCompatActivity {

    TextView continueas;
    Button logout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        getSupportActionBar().hide();
        setContentView(R.layout.activity_continue);
        continueas = findViewById(R.id.continueas);
        logout = findViewById(R.id.outbutton);


        SharedPreferences sharedPreferences = getSharedPreferences("User", Context.MODE_PRIVATE);
        String user = sharedPreferences.getString("user",null);

        continueas.setText("Continue as " + user);

        continueas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Continue.this,Main.class);
                startActivity(intent);
                finish();
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Continue.this,home.class);
                SharedPreferences sharedPreferences1 = getSharedPreferences("Logged",Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences1.edit();
                editor.putString("Login","False");
                editor.apply();
                startActivity(intent);
                finish();
            }
        });


    }
}