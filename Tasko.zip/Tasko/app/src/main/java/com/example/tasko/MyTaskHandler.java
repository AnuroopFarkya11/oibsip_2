package com.example.tasko;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

//                                  DATABASE HANDLER CODE FOR TASK DETAILS


public class MyTaskHandler extends SQLiteOpenHelper {

    //DATABASE NAME
    public static final String DATABASE = "TASKO";

    //TABLE DETAILS
    public static final String TABLE_NAME = "TASKS";

    //    public static final int SNO = 0;
    public static final String DATE="DATE";
    public static final String TITLE ="TITLE";
    public static final String TASK="TASK";
    public static final String USERS = "USER";

    RecyclerView showTask;
    Context context;




    public MyTaskHandler(Context context, RecyclerView showTask) {
        super(context, DATABASE, null, 1);
        this.showTask = showTask;
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        String sql = "CREATE TABLE " + TABLE_NAME + " (" + DATE + " TEXT, " + USERS + " TEXT, " + TITLE + " TEXT," +  TASK  + " TEXT );";
        DB.execSQL(sql);
//        DB.close();
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        sqLiteDatabase.execSQL("DROP TABLE " + TABLE_NAME);
        onCreate(sqLiteDatabase);
    }

    public void addTask(String date, String user,String title, String task)
    {
        Log.d("DataIn!","Adding started!" + date + user + title + task);

        SQLiteDatabase DB = this.getWritableDatabase();


        String sql = "INSERT INTO " + TABLE_NAME + " VALUES ('" + date + "', '" + user + "', '" + title + "', '" + task + "');";
        DB.execSQL(sql);
        DB.close();
    }

    public List<String> showTask(String user,String date)
    {
        Log.d("DataIn!","Showing date " + date +" "+user);
        SQLiteDatabase DB = this.getReadableDatabase();
//        String sql = "SELECT * FROM TASKS"  ;

        String sql = "SELECT * FROM " + TABLE_NAME + " WHERE " + DATE + "= '" + date + "' and " + USERS + " = '" + user + "'" ;
//        String sql = "SELECT * FROM " + TABLE_NAME;
        Cursor cursor = DB.rawQuery(sql,null);
        List<String> list = new ArrayList<>();


        if(cursor.moveToFirst())
        {
            do{
                String dinak;
                String Task;
                dinak = cursor.getString(0);
                Task = cursor.getString(3);

                //0 for username
                //1 for date
                //2 for title
                //3 for task

                list.add(Task);

                Log.d("DataIn!","Task : " + Task + dinak);
            }while(cursor.moveToNext());

        }
        return list;
    }

    public void delete(String user, String date, String task)
    {
        SQLiteDatabase DB = this.getReadableDatabase();
        String sql = "DELETE FROM " + TABLE_NAME + " WHERE " + USERS + " = '" + user + "' and " + DATE + " = '" + date + "' and " + TASK + " = '" + task +"'";
        DB.execSQL(sql);
        List<String> deleted = new ArrayList<>();
        deleted = showTask(user,date);

        showTask.setLayoutManager(new LinearLayoutManager(context));
        showTask.setAdapter(new ProgrammingAdapter(deleted,context,user,date,showTask));

    }

}
