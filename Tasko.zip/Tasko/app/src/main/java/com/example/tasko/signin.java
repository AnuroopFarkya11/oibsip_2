package com.example.tasko;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.tasko.DbHandler.MyDBHandler;
import com.example.tasko.Users.User;

import java.util.List;

public class signin extends AppCompatActivity {

    EditText email, password;
    ImageButton login;
    CheckBox check;
    Button forget;

   private static final String KEY ="com.example.tasko.Key";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signin);
        getSupportActionBar().hide();


        forget = findViewById(R.id.already);
        email = findViewById(R.id.email_Address);
        password = findViewById(R.id.password);
        login = findViewById(R.id.signup);
        check = findViewById(R.id.checkBox);
        MyDBHandler dbHandler = new MyDBHandler(this);

        SharedPreferences shared = getSharedPreferences("Logged", Context.MODE_PRIVATE);

        check.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(buttonView.isChecked())
                    {
                        SharedPreferences.Editor editor = shared.edit();
                        editor.putString("Login","True");
                        editor.apply();
                        Toast.makeText(signin.this, "Checked", Toast.LENGTH_SHORT).show();
                    }else{
                        SharedPreferences.Editor editor = shared.edit();
                        editor.putString("Login","False");
                        editor.apply();
                        Toast.makeText(signin.this, "Unchecked", Toast.LENGTH_SHORT).show();
                    }
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = email.getText().toString();
                String pass = password.getText().toString();

                if(username.equals("")||pass.equals(""))
                {
                    Toast.makeText(signin.this, "Please Enter All Fields!", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    boolean check = dbHandler.checkUserPass(username,pass);
                    if(check)
                    {
                        Toast.makeText(signin.this, "Login Successful!", Toast.LENGTH_SHORT).show();

                        SharedPreferences sharedPreferences = getSharedPreferences("User",Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("user",username);
                        editor.apply();
                        Intent intent = new Intent(signin.this,Main.class);
                        startActivity(intent);
                        finish();


                    }
                    else{
                        Toast.makeText(signin.this, "Invalid Credentials!", Toast.LENGTH_SHORT).show();
                        List<User> alluser = dbHandler.showUsers();

                        for(User temp : alluser)
                        {
//            str.append("User Name : " + temp.getUser_name() + "\nPassword : " + temp.getPassword() +"\n\n");
                            Log.d("Myquery","User Name : " + temp.getUser_name() + " Password : " + temp.getPassword() +"\n\n");
                        }
                    }
                }


            }
        });

        forget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                finish();




                String user = email.getText().toString();

                if(user.isEmpty())
                {
                    Toast.makeText(signin.this, "Enter Username!", Toast.LENGTH_SHORT).show();
                }
                else {

                    boolean check = dbHandler.checkUser(user);

                    if(check)
                    {
                        Intent intent = new Intent(signin.this, Reset.class);

                        intent.putExtra("KEY", user);

                        startActivity(intent);

                        finish();
                    }
                    else
                    {
                        Toast.makeText(signin.this, "Invalid User!", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });



    }
}