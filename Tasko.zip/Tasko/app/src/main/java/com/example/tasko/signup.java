package com.example.tasko;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.tasko.DbHandler.MyDBHandler;
import com.example.tasko.Users.User;

//                                               SIGNUP SCREEN : ASK FOR USER CREDENTIALS & SAVE TO DATABASE

public class signup extends AppCompatActivity {

    EditText user_name,email,password,confirm;
    ImageButton signup;
    Button already;

    User users = new User();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);
        getSupportActionBar().hide();
        MyDBHandler dbHandler = new MyDBHandler(this);


        user_name = findViewById(R.id.user_name);
        email = findViewById(R.id.email_Address);
        password = findViewById(R.id.password);
        confirm = findViewById(R.id.confirmpassword);
        signup = findViewById(R.id.signup);
        already = findViewById(R.id.already);
//        Intent intent = new Intent(this,MainActivity6.class);


        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user=user_name.getText().toString();
                String mail=email.getText().toString();
                String pass = password.getText().toString();
                String repass = confirm.getText().toString();

                if(user.equals("")||mail.equals("")||pass.equals("")||repass.equals(""))
                {
                    Toast.makeText(com.example.tasko.signup.this, "Please enter all fields!", Toast.LENGTH_SHORT).show();
                }
                else{
                    if(pass.equals(repass)){
                        boolean checkEmailUser = dbHandler.checkEmailUser(mail,user);
                        if(!checkEmailUser)
                        {
                            users.setUser_name(user);
                            users.setEmail(mail);
                            users.setPassword(pass);
                            boolean insert = dbHandler.addUser(users);
                            if(insert)
                            {
                                Toast.makeText(com.example.tasko.signup.this, "Sign Up Successful!", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(signup.this,home.class);
                                SharedPreferences sharedPreferences = getSharedPreferences("User", Context.MODE_PRIVATE);
                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                editor.putString("user", users.getUser_name());
                                editor.apply();
                                startActivity(intent);
                                finish();
                            }
                            else
                            {
                                Toast.makeText(com.example.tasko.signup.this, "Sign Up Unsuccessful!", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{
                            Toast.makeText(com.example.tasko.signup.this, "Account already exists!", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else {
                        Toast.makeText(com.example.tasko.signup.this, "Password MisMatched!", Toast.LENGTH_SHORT).show();
                    }
                }

//                if(pass.equals(confirm.getText().toString()))
//                {
//                    users.setPassword(password.getText().toString());
//                    dbHandler.addUser(users);
//                    startActivity(intent);
//
//                }
//                else{
//                    Toast.makeText(MainActivity5.this, "Password Doesn't Match!", Toast.LENGTH_SHORT).show();
//                }

            }


        });


        already.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(signup.this,signin.class);
                startActivity(intent);
                finish();
            }
        });





    }
}