package com.example.tasko.Users;

public class User {
    private int id;
    private String User_name;
    private String Email;
    private String Password;

    public User()
    {

    }

    public User(String user_name, String email, String password) {
        User_name = user_name;
        Email = email;
        Password = password;
    }

    public User(int id, String user_name, String email, String password) {
        this.id = id;
        User_name = user_name;
        Email = email;
        Password = password;
    }

    public int getId() {
        return id;
    }

    public String getUser_name() {
        return User_name;
    }

    public String getEmail() {
        return Email;
    }

    public String getPassword() {
        return Password;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setUser_name(String user_name) {
        User_name = user_name;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public void setPassword(String password) {
        Password = password;
    }
}
