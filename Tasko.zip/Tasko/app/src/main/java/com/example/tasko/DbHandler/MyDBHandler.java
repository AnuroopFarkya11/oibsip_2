package com.example.tasko.DbHandler;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.ContentView;
import androidx.annotation.Nullable;

import com.example.tasko.Users.User;

import java.util.ArrayList;
import java.util.List;

//                                  DATABASE HANDLER CODE FOR USER CREDENTIALS


public class MyDBHandler extends SQLiteOpenHelper {
    //Here declare the attributes of databse and table

    public static final String DATABASE_NAME = "USER";

    public static final String TABLE_NAME = "CREDENTIALS";
    public static final String SNO = "SNO";
    public static final String USER_NAME ="USER_NAME";
    public static final String EMAIL="EMAIL_ADDRESS";
    public static final String PASSWORD ="PASSWORD";

    public MyDBHandler(Context context) {
        super(context,DATABASE_NAME, null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + " ("+SNO + " INTEGER ," + USER_NAME + " TEXT PRIMARY KEY," + EMAIL +" TEXT, "+ PASSWORD + " TEXT " + ")";
        db.execSQL(query);
        Log.d("MyQuery","Table created successfully!");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        String dropping = "DROP TABLE IF EXISTS " + TABLE_NAME;
        db.execSQL(dropping);

        onCreate(db);

    }
    public boolean addUser(User user)
    {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(USER_NAME,user.getUser_name());
        values.put(EMAIL,user.getEmail());
        values.put(PASSWORD,user.getPassword());

        long result = db.insert(TABLE_NAME,null,values);
        Log.d("Myquery","USER ADDED!");
        db.close();

        if(result == -1)
        {
            return false;
        }
        return true;

    }

    public List<User> showUsers()
    {
        List<User> userList = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME;
        Cursor cursor = db.rawQuery(query,null);

        if(cursor.moveToNext())
        do{
            User temp = new User();
//            temp.setId(Integer.parseInt(cursor.getString(0)));
            temp.setUser_name(cursor.getString(1));
            temp.setEmail(cursor.getString(2));
            temp.setPassword(cursor.getString(3));
            userList.add(temp);


        }while(cursor.moveToNext());

        return userList;
    }

    public boolean checkEmailUser(String email,String User)
    {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " + EMAIL + " =?",new String[]{email});
        Cursor cursor1 = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE "+ USER_NAME + " =?",new String[]{User});


        return (cursor.getCount() > 0 && cursor1.getCount()>0);
    }

    public boolean checkUserPass(String email, String pass)
    {
            SQLiteDatabase db = getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " + USER_NAME + " =? and " + PASSWORD + " =?",new String[]{email,pass});
        return cursor.getCount() > 0;
    }


    public Boolean changePass(String user, String npass)
    {
        Log.d("Myquery",user+" "+npass);
        SQLiteDatabase db = getWritableDatabase();
//        String query = "UPDATE " + TABLE_NAME +" SET " + PASSWORD + " = '" + npass + "' WHERE " + EMAIL + " = '" + user + "'";
        ContentValues values = new ContentValues();
        values.put(EMAIL,user);
        values.put(PASSWORD,npass);
//        String where = "EMAIL_ADDRESS = " + user;

        int res=db.update(TABLE_NAME,values,EMAIL+"=?",new String[]{user});
        db.close();

        return res != -1;

    }
    public boolean checkUser(String user)
    {
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM " + TABLE_NAME + " WHERE " + USER_NAME + "=?";
        Cursor cursor = db.rawQuery(sql,new String[]{user});

        return cursor.getCount()>0;

    }

}
