package com.example.tasko;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tasko.DbHandler.MyDBHandler;
//                                               RESET PASSWORD SCREEN : RESETS THE PASSWORD

public class Reset extends AppCompatActivity {

    EditText newpass,confirmpass;
    ImageButton change;
    TextView hiuser;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset);
        getSupportActionBar().hide();

        newpass = findViewById(R.id.newpass);
        confirmpass = findViewById(R.id.conpass);
        change = findViewById(R.id.change);
        hiuser = findViewById(R.id.hiuser);



        MyDBHandler myDBHandler = new MyDBHandler(this);
        Intent intent = getIntent();
        String user = intent.getStringExtra("KEY");
//        Log.d("Myquery",user);

        hiuser.setText("Hey "+ user);


        change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String npass = newpass.getText().toString();
                String cpass = confirmpass.getText().toString();


                if(npass.isEmpty()||cpass.isEmpty())
                {
                    Toast.makeText(Reset.this, "Enter value to all fields!", Toast.LENGTH_SHORT).show();

                }
                else if(npass.equals(cpass))
                {

                    Boolean updated = myDBHandler.changePass(user,cpass);
                    if(updated) {
                        Toast.makeText(Reset.this, "Password Changed!", Toast.LENGTH_SHORT).show();
                        finish();
                        Intent intent1 = new Intent(Reset.this,signin.class);
                        startActivity(intent1);


                    }
                    else{
                        Toast.makeText(Reset.this, "Password could not be updated!", Toast.LENGTH_SHORT).show();
                    }


                }
                else{
                    Toast.makeText(Reset.this, "Password Mismatched!", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
}